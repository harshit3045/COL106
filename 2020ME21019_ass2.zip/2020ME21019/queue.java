

public class queue {
    Node head;
    Node tail;
    int size;
    public queue(){
        this.head = null;
        this.tail = null;
        size=0;
    }

    class Node{
        Object obj;
        Node next;
        public Node(Object obj){
            this.obj = obj;
            this.next = null;
        }
    }

    void enqueue(Object obj){
        Node n=new Node(obj);

        if(this.tail == null)
        {
            this.head = n;
            this.tail = n;
            size++;
            return;
        }

        else this.tail.next = n;
        this.tail = n;
        size++;
        return;

    }
    Object dequeue(){

        if(this.head == null ){
            return null;
        }

        Node node = this.head;
        this.head = this.head.next;
        size--;
        if(this.head == null)
        this.tail = null;

        return node.obj;
    }
    public static void main(String[] args)
    {
        queue q = new queue();
        q.enqueue(10);
        q.enqueue(20);
        q.dequeue();
        q.dequeue();
        q.enqueue(30);
        q.enqueue(40);
        q.enqueue(50);
        q.dequeue();
        System.out.println("Queue Front : " + q.head.obj);
        System.out.println("Queue Rear : " + q.tail.obj + " "+q.size);

    }
}
