//Node for avl tree
class Node {
	int id, height;
	Node left, right;

	secNode refToSecTree; //reference to secondary tree

	// int level=0;
	// Node boss;
	// int noOfEmployee=0;
	// Node employee[] = new Node[100];

	Node(int d) {
		id = d;
		height = 1;
		refToSecTree = null;
	}
	void printNode(){
		System.out.println("**********\nid is " +id+ "\n level is " + refToSecTree.level + "\n boss is "+ refToSecTree.boss.id + "\n no of employee are " + refToSecTree.noOfEmployee  +" \n***********");
	}
	
}
//secondary node for secondary tree
class secNode{
	int id = 0;
	int level=0;
	secNode boss  = null;
	int noOfEmployee=0;
	secNode employee[] = new secNode[100];

	secNode(int d){
		this.id = d;
}
}

//secondary tree
class sectree{
	secNode root=null;

}

public class OrgHierarchy implements OrgHierarchyInterface{

// create a new AVL tree and its secondary tree
avltree tree = new avltree();
sectree sect = new sectree();


//debugging function to get the avl tree
public avltree getTree(){
	return tree;
}
// function to tell if the organisation is empty
public boolean isEmpty(){
	// get the avl tree's size and tell if its empty or not
	if (tree.size == 0) {
		return true;
	}
	return false;
} 

//function to return the size of the organisation
public int size(){
	// return size of tree. size of tree is same as size of organisation
	return tree.size;
	
}

// function to return level of an employee
public int level(int id) throws IllegalIDException{
	//search the id in the avl tree
	Node n = tree.search(tree.root, id);

	// throw exception if id does not exist. (our tree returns null if the id is not found)
	if( n == null)
	throw new IllegalIDException("Not implemented yet.");

	//return the node's level. Level's are stored as an instance variable in a secondary node.
	return n.refToSecTree.level;
} 

// function to hire owner
public void hireOwner(int id) throws NotEmptyException{

	// if tree is not null then owner already exists.
	if(tree.root != null) {
		throw new NotEmptyException("Owner already exists");
	}

	//create a new node from the id and its secnode
	Node node = new Node(id);
	secNode secy=new secNode(id);

	//connecting node and secnode
	node.refToSecTree = secy;

	//set its level
	node.refToSecTree.level = 1;                // give the node a level. Owner's level is 1

	tree.root = tree.insert(tree.root, node);   // insert the node in avl tree

}

public void hireEmployee(int id, int bossid) throws IllegalIDException{

	 //create new nodes for both the trees
	Node newhire = new Node(id);
	secNode newsecnode = new secNode(id);

	// link the nodes
	newhire.refToSecTree = newsecnode;

	//find the boss in avl tree
	 Node boss = tree.search(tree.root, bossid);

	 //throw error if this id already exists or if the bossid does not exist
	 if(tree.search(tree.root, id) != null || boss.id != bossid )
	 throw new IllegalIDException("Employee can't be hired");

	//setting up the secnode's details
	 newsecnode.boss = boss.refToSecTree;
	 newsecnode.level = boss.refToSecTree.level +1;

	 //insert the node in avl tree
	 tree.root = tree.insert(tree.root, newhire);
	
	 //adding the secnode in its boss's employee array
	 for(int i=0 ;i <boss.refToSecTree.noOfEmployee + 1; i++) {
		 if(boss.refToSecTree.employee[i]==null){
			boss.refToSecTree.employee[i]=newsecnode;
			boss.refToSecTree.noOfEmployee++;
			 break;
		 }
	}
	 return;
	 
}

//function to print id's of a node array. used in debugging
public void print(Node n[]){
	System.out.println("printing.....");
	for(int i=0 ; i<n.length;i++) {
		try {
			System.out.println(" "+ n[i].id);
		} catch (NullPointerException e) {
			System.out.print(" N ");
		}
		
	}
	System.out.println("..............");
}
//function to print an integer array. used in debugging
public void print(int arr[]){
	System.out.println("===printing int array====");
	for (int i : arr) {
		System.out.println(i);	
	}
	System.out.println("===int arry printed ===");
}

public void fireEmployee(int id) throws IllegalIDException{

	//search the node getting fired
	Node employeeGettingFired = tree.search(tree.root, id);

	
	//if no such node exists, or if it manages other employess or if it is level 1 employee, throw exception 
	if(employeeGettingFired == null || employeeGettingFired.refToSecTree.noOfEmployee != 0 || employeeGettingFired.refToSecTree.level ==1 )
	{ 
		throw new IllegalIDException("Can't fire this employee");}
	 
	int i=-1;

	// delete the node from employee array
	do{i++;}
	while( i < 100 && employeeGettingFired.refToSecTree.boss.employee[i] != employeeGettingFired.refToSecTree);
	
		
	// skipping until the employee is found
	employeeGettingFired.refToSecTree.boss.employee[i] = null; // You're fired!
	// updating no. of employees of boss

	employeeGettingFired.refToSecTree.boss.noOfEmployee--;

	//clearing the node
	employeeGettingFired.refToSecTree.boss = null;

	// delete the node from avl tree
	tree.root = tree.deleteNode(tree.root,id);
	
	return;
}


public void fireEmployee(int id, int manageid) throws IllegalIDException{
	//find the employee to be fired
	Node tobefired = tree.search(tree.root, id);

	// find the new manager
	Node newBoss = tree.search(tree.root, manageid);

	// if the employee or manager does not exist or its a level 1 employee, throw exception
	if(tobefired == null || newBoss == null || tobefired.refToSecTree.level == 1)
	throw new IllegalIDException("Not implemented yet.");

	// function to transfer employees of the employee getting fired to the new manager
	int temp=0;  // counter for new managers's employee array

	for (int j=0; j< tobefired.refToSecTree.noOfEmployee; j++) { // j is counter for old manager's employee array
		if(tobefired.refToSecTree.employee[j] != null){

			// move in the array until a blank space is found in new managers employee array
			while(newBoss.refToSecTree.employee[temp]!= null){
				temp++;
			}
			// transferrring the employee
			newBoss.refToSecTree.employee[temp++] = tobefired.refToSecTree.employee[j];
			tobefired.refToSecTree.employee[j].boss = newBoss.refToSecTree;
			tobefired.refToSecTree.employee[j].level = newBoss.refToSecTree.level + 1;
		}
	}

	//update no. of employees of new boss
	newBoss.refToSecTree.noOfEmployee = newBoss.refToSecTree.noOfEmployee + tobefired.refToSecTree.noOfEmployee;

	// deleting the employee from its boss's employee array
	int i=-1;
	do{i++;}
	while(tobefired.refToSecTree.boss.employee[i] != tobefired.refToSecTree); // skip the array until the employee getting fired is found
	tobefired.refToSecTree.boss.employee[i] = null;    // You're fired!

	//updating no. of employees of boss whose employee got fired.
	tobefired.refToSecTree.boss.noOfEmployee--; 

	//clearing the fired secnode
	tobefired.refToSecTree.employee = null;
	tobefired.refToSecTree.boss = null;

	//delete the employee from avl tree
	tree.root = tree.deleteNode(tree.root, id);
	
	
} 

public int boss(int id) throws IllegalIDException{
	// search for the id in tree
	Node node = tree.search(tree.root, id);
	
	// if the id does not exist, throw exception
	if(node == null) throw new IllegalIDException("Not implemented yet.");

	// if node is owner, return value meant for owner
	if(node.refToSecTree.level == 1) return -1;

	// else return the boss's id
	return node.refToSecTree.boss.id;
	 
}

public int lowestCommonBoss(int id1, int id2) throws IllegalIDException{
	//search for both the id's in tree and go to thier secnodes
	secNode n1 = tree.search(tree.root, id1).refToSecTree;
	secNode n2 = tree.search(tree.root, id2).refToSecTree;

	//if either one of them does not exist throw exception
	if ( n1 == null || n2 == null )   throw new IllegalIDException("Not implemented yet.");

	//if one of the input id is owner return value as per question
	if( n1.level == 1 || n2.level == 1) return -1;

	// go up the sectree from both the secnodes and store the bosses in two separate arrays
	int arr1[] = new int[tree.size];
	int arr2[] = new int[tree.size];
	int i=0;
	// going up the boss for node 1
	do{
		arr1[i++] = n1.id;
		n1=n1.boss;
		
	}while(n1 != null );
	i--;

	//going up the boss for node 2
	int j=0;
	do{
		arr2[j++] = n2.id;
		n2=n2.boss;
		
	}while(n2 != null );
	j--;
	
	
	//traverse both the array from last as long as they are same; the id just before they start getting different is the last common boss id
	while(arr1[i] == arr2[j] && i >0 && j>0 ){
		i--; j--;
	}
	
	//return the common boss's id just after i
	if(i < 0) return arr1[0];
	else if (j < 0) return arr2[0];
	
	return arr1[i+1];
	 
}

// sort array using insertion sort algorithm
public int[] sort(int[] array, int length){

	for (int i = 0; i < length; i++) {
		int key= array[i];
		int j=i-1;

		while(j>=0 && array[j] > key){
			array[j+1] =array[j];
			j--;
		}
		array[j+1] = key;
	}
	
	return array;
}

// fucntion to add two arrays. Adds array2 to array1 and returns array1;
public int[] add(int array1[],int length1, int array2[], int length2){
	int i=0, sum = length1 + length2;
	
	while(length1 < sum){
		array1[length1++] = array2[i++];
	}

	return array1;

}

// the infamous toString() method. Returns the whole tree as a string

public String toString(int id) throws IllegalIDException{

	//search for both the id's in tree and go to its secNode
	secNode node = tree.search(tree.root, id).refToSecTree;

	//if id does not exist or if the tree is null throw exception
	if(tree.size == 0){
		throw new IllegalIDException("Not implemented yet.");
	}

	// the string that will be returned
	String s="";


	/*
		Approach: From the given root secnode, add it in queue. Nodes in queue will dequeued one by one. Their children enqueued and their
		id's added in temp. Whenever the number of childeren on a level are finished being added, the temp array sorts and adds into main
		array and refreshes itself. The main array will be converted to a returnable string. 
	*/
	
	// a temp array that stores the chilren that are being traversed.
	// it will be passed into sort and then added into main array; 'array'
	int length = 0;  // counts the number of elements in temp
	int temp[] = new int[100];

	int count = 0;   // counts the number of elements in array
	int array[] = new int[tree.size]; // the main array that will be turned to string

	//queue to store the secnodes to be traversed. Handmade and implemented in queue.java file by this humble student
	queue q= new queue();

	/*
	counters to determine level. 
	counter1 stores how many elements are to be dequeued for this level. counter2 stores counts how many elements will be dequeued on next level.
	when counter1 becomes 0; the level is complete. temp sorts and merges into array and counter2 goes into counter1 and itself refreshes to 0
	*/

	int counter1,counter2=0;

	// enqueuing the given root in queue.
	q.enqueue(node); counter1=1;

	// adding the root to main array
	array[0]=node.id; count++;

	// queue does not become empty
	while(q.size != 0 )
	{
		//dequeuing the queue. decreasing counter1 that counts the number of elements on this level
		secNode n=(secNode) q.dequeue(); counter1--;
		counter2 += n.noOfEmployee; // counter2 counts the elements that will be traversed in next level
		
		// for the dequeued elements ...........
		int countedNumberOfEmployees= 0;

		for(int i=0; i< 100 && countedNumberOfEmployees <= n.noOfEmployee; i++){
			if(n.employee[i] != null)
			{
				q.enqueue(n.employee[i]);           // enqueue each of the employess of that node
				temp[length++] = n.employee[i].id;  // store these children's id's in temp array.
				countedNumberOfEmployees++;
			}
		}

		// if the counter1 == 0; this means the this level has ended
		if(counter1 == 0){
			temp = sort(temp, length);        // sort the temp array
			add(array, count, temp, length);  //  add sorted temp to main 'array'
			count = count + length;           // update the number of entries in 'array'
			temp = new int[100];              // refreshing temp
			length=0;                         // refreshing temp's counter
			counter1 = counter2;              // transferrring number of nodes in next level to counter1
		counter2 =0;}                         // refreshing counter2

	}

	//converting array to string
	for (int i = 0; i < count; i++) {
		s+= " " + array[i];
	}
	s=s.trim();// trim the leading space
	
	//returning the final string
	return s;
	
	 
}

}


