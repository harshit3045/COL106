class InvalidPostfixException extends Exception{}
class InvalidExprException extends Exception{}


public class Calculator {

    static void print(int i){                   // shorthand for System.out.println()
        System.out.println(i);
    }
    static void print(String s){
        System.out.println(s);                   // shorthand for System.out.println()
    }


    static int getNum(Object o){
        return Character.getNumericValue((char) o);               // parses stack object into integer 
    }
    static boolean isNum(char c){
        return (c > 47 && c < 58 )? true:false;                    // check if a character is a num or not
    }

   
// part b) POSTFIX method
    public int evaluatePostFix(String s) throws InvalidPostfixException{

        int ans = 0;       // variable to return final answer
        int len = s.length();

        MyStack stack = new MyStack();
        
        int i = 0;          // pointer for input string traversal

        // string traversal starts
        while( i < len ) {
            
            // read char at i
            char c = s.charAt(i);

            // temporary string to read single or multi-digit number
            String temp = "";
            
            // if the char is a number push it in the stack 
            if(isNum(c)) 
            {
                while( i < len && isNum( s.charAt(i)) ) {
                temp += s.charAt(i++);
                }
                i--;

            stack.push(Integer.parseInt(temp));            // push the number into stack
            }

            // else if the char is an operator
            else if (c == '+' || c == '-' || c == '*'){

                try {           // to catch for .pop() method error 
                    
                    if ( stack.t >= 1 ) {     // can operate only if stack has more than two elements
    
                        if( c == '+' ){        // + operation
                        
                            int element1 = (int) (stack.pop());
                            int element2 = (int) (stack.pop());
    
                            stack.push(element1 + element2);  
                        }
                        else if( c == '-' ){                // - operation
                            
                            int element1 = (int) (stack.pop());
                            int element2 = (int) (stack.pop());
    
                            stack.push(element2 - element1);
                        }
                        else if( c == '*' ){                   // * operation
                             
                            int element1 = (int) (stack.pop());
                            int element2 = (int) (stack.pop());
    
                            stack.push(element1 * element2);
                        }
                        else throw new InvalidPostfixException();   //error if operator is none of these
                    }
                    else throw new InvalidPostfixException();       // stack length is less than two
    
                } catch (EmptyStackException e) {
                    throw new InvalidPostfixException();            // if error from stack
                    
                }
                
                                 
            }

            // for one or more whitespace
            else if ( c == ' '){
                while( s.charAt(i) == ' ' ){ i++; }
                i--;
            }
            else throw new InvalidPostfixException();       // if char is none of the operable characters 
        i++;
        }
            
        try {
            // if stack is not empty, then invalid expression
            if(stack.t != 0) throw new InvalidPostfixException();   

            // getting final ans from stack
            else ans = (int) (stack.top()); 

        }catch( EmptyStackException e ){ throw new InvalidPostfixException();}
        
        // finally returning ans
        return ans;
    }

// part c) ConvertExpression Method 

    public String convertExpression( String s) throws InvalidExprException {

        MyStack stack = new MyStack();      // stack to hold operators

        // string to hold the final returnable string
        String ans = "";

        // input string length
        int len = s.length();

        
        
    try{
        // integer for traversing the string
        int i=0;
        while( i < len ){

            // to take a number input whether its multi digit or one digit
            String temp = "";
            
            if( isNum( s.charAt(i) ) ) {
                while( i < len && isNum( s.charAt(i)) ) {
                temp += s.charAt(i++);
                }
                ans += temp + " ";
                if( i == len) break;
            }
            
            // if space is read
            while( s.charAt(i) == ' ' ){ i++; }

            // for operators
                if( s.charAt(i) == '+' || s.charAt(i) == '-' ){

                    if( !stack.isEmpty() && (char) stack.top() == '*'){ // if high precedence operator is below
                        ans += stack.pop() + " ";

                    }
                    if( !stack.isEmpty() && ((char) stack.top() == '+' || (char) stack.top() == '-') ){ // if equal precedence operator is below
                        ans += stack.pop() +" ";

                    }
                    
                    stack.push(s.charAt(i++));

                }

                else if(s.charAt(i) == '*' || s.charAt(i) == '(' ){         // operator * or open bracket 
                    stack.push(s.charAt(i++));
                }

                else if(s.charAt(i) == ')'){  
                                                  // if char is close bracket; pop everything until open bracket 
                    while( !stack.isEmpty() && (char) stack.top() != '('){
                        ans += stack.pop() + " ";
                    }

                    stack.pop(); 
                    i++;
                }

                else if( isNum( s.charAt(i) ) ) continue;   // if a number is encountered at this stage, move to next iteration

                else { 
                    throw new InvalidExprException();  // if none of operable character
                }           
            

        }
        while(!stack.isEmpty() && (char) stack.top() != '(' ){     // finally popping whaterver is in the stack and checking for paranthesis
            ans += stack.pop() + " ";
        }
        // for extra parantheses
        if( !stack.isEmpty() ) throw new InvalidExprException();
        
    }catch(EmptyStackException e){print("Empty stack exception "); throw new InvalidExprException();} // for stack pop operations

        try{
            ans=ans.trim(); // remove trailing space
            evaluatePostFix(ans); // if it can be evaluated, it would be valid expression otherwise not
        } 
        catch(InvalidPostfixException e)
        {throw new InvalidExprException();}
              
    return ans;

    }


    // public static void main(String[] args) {
    //     // String test = "4 6 + 9 * 5 7 * + 3 *";
    //     // int i = 0;
    //     String temp = "50*10*2*3";
    //     // Scanner sc=new Scanner(System.in);
    //     // temp = sc.nextLine();
    //     // sc.close();
        
    //     Calculator c= new Calculator();

    //     try{ 
    //         //i = Calculator.evaluatePostFix(test);
    //         temp = c.convertExpression(temp);

    //     }
    //     //catch(InvalidPostfixException e){ print("Invalid Post fix Exception"); }
    //     catch(InvalidExprException e){print("Invalid Expression exception");}

    //     System.out.println(temp);
    // }
}
