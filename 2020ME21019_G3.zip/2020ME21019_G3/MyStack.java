public class MyStack implements StackInterface {


    Object array[] = new Object[1];            // main array implementing the stack
    int t=-1;                                  // pointer to last array element

    // PUSH code
        public void push(Object o){
            if(o != null) 
            {t++;
            if(array.length == t)              // check if array is filled
            {
                // DOuble the array size
                Object temp_array[] = new Object[array.length * 2];
                int i = 0;
                for (Object object : array) {
                    temp_array[i++] = object;
                }
                    array = temp_array;

            }

            // actual pushing of object
            array[ t ] = o;
            System.out.println(toString());
        }
            
        }

    // POP code    
        public Object pop() throws EmptyStackException{
            // check if stack is empty
            if ( t < 0 ){
            throw new EmptyStackException(); 
            }
            else
            {   // actual popping
                t = t - 1;
                System.out.println(toString());
                return array[ t + 1 ];
            }
        }
    
        public Object top() throws EmptyStackException{
            // check if stack is empty otherwise return top element
            if(t >= 0) {System.out.println(toString());return array[t];}
            else throw new EmptyStackException();

        }

        // check if stack is empty
        public boolean isEmpty(){
            if(t < 0) { return true;} 
            else return false;
        }

        // converting stack into string with specified formatting
        public String toString(){
            
            if(isEmpty() == true) {return "[]";}
            else {     
                String s="[";               // adding intial bracket

                for (int i = t; i >= 0 ; i--) {
                
            
                s += array[i] + ", ";
            }

            // adding bracket formatting to the end of the string 
            s = s.substring( 0, s.length() - 2) + "]";

            return s;

        }
        }

        public static void main(String[] args) {
            
            MyStack s = new MyStack();
            System.out.println(s.toString());
            s.push("string1");
            System.out.println(s.toString());
            s.push(null);
            try {
                s.pop();
            } catch (EmptyStackException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            System.out.println(s.toString());
               
        }
}

