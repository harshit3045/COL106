

public class queue {
    QNode head;
    QNode tail;
    int size;
    int id;
    
    public queue(){
        this.head = null;
        this.tail = null;
        size=0;
        id = 0;
    }
    public queue(int idnum){
        this.head = null;
        this.tail = null;
        size=0;
        id = idnum;
    }

    class QNode{
        Object obj;

        QNode next;
        public QNode(Object obj){
            this.obj = obj;
            this.next = null;
        }
        HNode toHNode(QNode n){
            customer c= (customer) n.obj;
            HNode hnode = new HNode(c.waitTime);
            return hnode;
        }
    }

    void enqueue(Object obj){
        QNode n=new QNode(obj);

        if(this.tail == null)
        {
            this.head = n;
            this.tail = n;
            size++;
            return;
        }

        else this.tail.next = n;
        this.tail = n;
        size++;
        return;

    }
    Object dequeue(){

        if(this.head == null ){
            return null;
        }

        QNode Qnode = this.head;
        this.head = this.head.next;
        size--;
        if(this.head == null)
        this.tail = null;

        return Qnode.obj;
    }

    
    public static void main(String[] args)
    {
        queue q = new queue();
        q.enqueue(10);
        q.enqueue(20);
        q.dequeue();
        q.dequeue();
        q.enqueue(30);
        q.enqueue(40);
        q.enqueue(50);
        q.dequeue();
        System.out.println("Queue Front : " + q.head.obj);
        System.out.println("Queue Rear : " + q.tail.obj + " "+q.size);

    }
}
