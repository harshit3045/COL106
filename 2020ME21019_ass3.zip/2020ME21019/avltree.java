
class Node {
	int id, height;
	Node left, right;

	customer cust; //reference to secondary tree

	// int level=0;
	// Node boss;
	// int noOfEmployee=0;
	// Node employee[] = new Node[100];

	Node(customer c) {
		id = c.custId;
		height = 1;
		cust = c;
	}
}
//implementation of avl tree
class avltree {

	Node root;
	int size;

	// function that returns the height of the node
	int height(Node n) {
		if (n == null) return 0;

		return n.height;
	}

	// function that returns maximum of two integers
	int max(int x, int y) {
		return (x >y)? x : y;
	}

	// function to return the smallest value in a tree from a node 
    Node smallestNode(Node node)
    {
        Node temp = node;
 
        // because left node stores smaller value keep going left
        while (temp.left != null)
        temp = temp.left;
		
		//return the smallest node
        return temp;
    }

	// fucntion that gives the balance factor at node N
	int getBalance(Node n) {
		if (n == null) return 0;

		else return height(n.left) - height(n.right);
	}

	// function that right rotates subtree with y as root
	Node rightRotate(Node y) {
		Node x = y.left;
		Node zx = x.right;

		//rotating
		
		x.right = y;
		y.left = zx;
		

		// Updating the heights
		y.height = max(height(y.left), height(y.right)) + 1;
		x.height = max(height(x.left), height(x.right)) + 1;

		// Return the rotated node
		return x;
	}

	// function that left rotates the subtree with x as root
	Node leftRotate(Node x) {
		Node y = x.right;
		Node zx = y.left;

		// rotating
		y.left = x;
		x.right = zx;

		// Updating the heights
		x.height = max(height(x.left), height(x.right)) + 1;
		y.height = max(height(y.left), height(y.right)) + 1;

		// Return the rotated node
		return y;
	}
	
	//function to search and return a node
	Node search(Node n, int key){
		if( n == null) {
			return null;
		}
        if(n.id == key) return n;
        else if(n.id > key) return search(n.left, key);
        else if(n.id < key) return search(n.right, key);
	
        return null;
    }

	Node insert(Node node, Node insert) {

		// actual insertion
		if (node == null){ //update size of tree
				size++; 
				return insert;
		}
		//searching for a place
		if (insert.id > node.id)
			node.right = insert(node.right, insert);
		else if (insert.id < node.id)
			node.left = insert(node.left, insert);
		else return node;

		// Updating the height of this node
		node.height = 1 + max(height(node.right), height(node.left));

		// get balance factor
		int bal = getBalance(node);

		// If node is unbalanced

		if (bal > 1 && insert.id < node.left.id){	
			return rightRotate(node);
		}
		
		if (bal > 1 && insert.id > node.left.id) {
			node.left = leftRotate(node.left);
			return rightRotate(node);
		}

		if (bal < -1 && insert.id > node.right.id){
			return leftRotate(node);
		}

		if (bal < -1 && insert.id < node.right.id) {
			node.right = rightRotate(node.right);
			return leftRotate(node);
		}

		// returning the node
		return node;
	}
 
	// function to delete a node with given id
    Node deleteNode(Node root, int id)
    {
        // actual delete
        if (root == null)
            return root;
 
        // finding the node to be deleted
		if (id > root.id)
			root.right = deleteNode(root.right, id);
        else if (id < root.id)
            root.left = deleteNode(root.left, id);
 
        // here the id is equal and this node is to be deleted
        else{
 
            // CASE: one of right and left is empty
            if (root.left == null || root.right == null)
            {
				//decreasing the size of tree
				size--;

                Node temp = null;
                if (temp == root.left)
                    temp = root.right;
                else temp = root.left;

				//if it's still empty means both are null

                if (temp == null){
                    temp = root;
                    root = null;
                }
				// if there's one and only one child
                else root = temp; // move the node
            }
            else{
                // if there are two children of the node find its heir
                Node temp = smallestNode(root.right);
 
                // move the heir to the node
                root.id = temp.id;
				root.cust = temp.cust;

 
                // Delete the heir after its data has been transferred from the tree below it
                root.right = deleteNode(root.right, temp.id);
            }
        }
 
        // If the tree had only one node then return
        if (root == null) return root;
 
        // Update the height of the node
        root.height = 1 + max(height(root.left), height(root.right));
 
        // find the balance factor
        int bal = getBalance(root);
 
        // check if the node is unbalanced and balance it
        if (bal > 1 && getBalance(root.left) >=0)
            return rightRotate(root);
		
		if (bal < -1 && getBalance(root.right)> 0)
		{
			root.right = rightRotate(root.right);
			return leftRotate(root);
		}
 
        if (bal > 1 && getBalance(root.left)< 0)
        {
            root.left = leftRotate(root.left);
            return rightRotate(root);
        }
 
        if (bal < -1 && getBalance(root.right) <=0)
            return leftRotate(root);
 
        //return the node
        return root;
    }
	
    	
}
