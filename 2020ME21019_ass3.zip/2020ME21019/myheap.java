// class customer{

//     int custId;
//     int state=0;
//     int numb;
//     int arrTime;
//     int waitTime=0;
//     int pop_time=0;
//     int q_id=0;
//     int cooking_burg = 0;
//     int done_burg=0;

//     public customer(int id, int timeofArrival, int burger){
//         custId = id;
//         numb = burger;
//         arrTime = timeofArrival;
//     }


// }

// class HNode{
//     int key; //size
//     int data; // id

//     customer c;
//     //myDeque d;
//     public HNode(int x){
//         key = x;
//         data = 0;
//     }
// }


// public class myheap {

//      HNode arr[] =  new HNode[50];
//      int pointer = -1;

//     public myheap(int k){
//         arr = new HNode[k];

//         // for (int i = 0; i < k; i++) {
//         //  arr[i] = new HNode(i+1);   
//         // }

//     }

//      int parent(int j){
//         return (j-1) / 2;
//     }

//      int left(int j){
//         return 2*j +1;
//     }

//      int right(int j){
//         return 2*j + 2;
//     }

//      boolean hasLeft(int j){
//         return left(j) <= pointer;

//     }

//      boolean hasRight(int j){
//         return right(j) <= pointer;

//     }

//      void upheap(int j){

//         while(j> 0 && arr[parent(j)].key > arr[j].key){
        
//             swap(j, parent(j));

//             j = parent(j);

//         }
//     }

//      void downheap(int j){
//         //System.out.println("downheap called");
//         while(hasLeft(j)){
//             //System.out.println("loop started. size is " + pointer);
//             int leftIndex = left(j);
//             int smallChildIndex = leftIndex;
//             if(hasRight(j)){
//                 int rightIndex = right(j);
//                 if (arr[rightIndex].key < arr[leftIndex].key)
//                 {
//                     smallChildIndex = rightIndex;
//                 }
//             }
//             if(arr[smallChildIndex].key >= arr[j].key){
//                 break;
//             }
//             swap(j,smallChildIndex);
//             j = smallChildIndex;
//         }
//     }

//      void swap(int i,int j){
//         HNode temp = arr[i];
//         arr[i] = arr[j];
//         arr[j] = temp;
//     }

//      int size() { return pointer +1;}

//      boolean isEmpty() {
//         return pointer == -1;
//     }

//     HNode min(){
//         if(isEmpty()) return null;
//         else return arr[0];
//     }

//     HNode removeMin(){
//         if(isEmpty()) return null;

//         HNode answer = arr[0];
//         arr[0] = arr[pointer];
//         pointer --;

//         downheap(0);
//         return answer;
//     }

//     HNode insert(HNode q){
//         pointer ++;

//         arr[pointer] = q;

//         upheap(pointer);

//         return q;
//     }

//     public String toString(){
//         String s="";
//         for (HNode hNode : arr) {
//             s+=hNode.key + " " +hNode.data + ", ";
//         }
//         return s;
//     }
//     // void queueCustomer(customer c){
//     //     c.state = min().id ;
//     //     min().enqueue(c);
//     //     downheap(0);
//     // }


//     public static void main(String[] args)
// {

// /*		      45
// 			/	 \
// 		 31 	 14
// 		/ \      / \
// 	  13  20    7 11
// 	 / \
// 	12 7
// 	Create a priority queue shown in
// 	example in a binary max heap form.
// 	Queue will be represented in the
// 	form of array as:
// 	45 31 14 13 20 7 11 12 7 */

// // Insert the element to the
// // priority queue
// /*queue q1= new queue(1);
// q1.size = 45;

// queue q2= new queue(2);
// q2.size = 20;

// queue q3= new queue(3);
// q3.size = 7;

// queue q4= new queue(4);
// q4.size = 12;

// queue q5= new queue(5);
// q5.size = 31;

// queue q6= new queue(6);
// q6.size = 7;

// queue q7= new queue(7);
// q7.size = 11;

// queue q8= new queue(8);
// q8.size = 7;

// queue q9= new queue(9);
// q9.size = 7;

// insert(q1);
// insert(q2);
// insert(q3);
// insert(q4);
// insert(q5);
// insert(q6);
// insert(q7);
// insert(q8);
// insert(q9);

// int i = 0;

// // Priority queue before extracting max
// System.out.print("#Priority Queue : ");
// while (i <= pointer)
// {
// 	System.out.print(arr[i].size + " ");
// 	i++;
// }

// System.out.print("\n");

// i = 0;

// // Priority queue before extracting max
// System.out.print("Priority Queue : ");
// while (i <= pointer)
// {
// 	System.out.print(arr[i].size + " ");
//     if(arr[i].size == 7 ) System.out.print(" id is "+ arr[i].id +" ");
// 	i++;
// }

// System.out.print("\n");

// // HNode with maximum priority
// System.out.print("HNode with maximum priority : " +
// 					removeMin().size + "\n");

// // Priority queue after extracting max
// System.out.print("Priority queue after removing minimum : ");
// int j = 0;
// while (j <= pointer)
// {
// 	System.out.print(arr[j].size + " ");
//     if(arr[j].size == 7) {System.out.print(" id is "+ arr[j].id +" ");}
// 	j++;
// }

// System.out.print("\n");
// //////////////////////////////////////////////////
// //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
// System.out.print("HNode with maximum priority : " +
// 					removeMin().size + "\n");

// // Priority queue after extracting max
// System.out.print("Priority queue after removing minimum : ");
//  j = 0;
// while (j <= pointer)
// {
// 	System.out.print(arr[j].size + " ");
//     if(arr[j].size == 7) {System.out.print(" id is "+ arr[j].id +" ");}

// 	j++;
// }

// System.out.print("\n");

// System.out.print("HNode with maximum priority : " +
// 					removeMin().size + "\n");

// // Priority queue after extracting max
// System.out.print("Priority queue after removing minimum : ");
//  j = 0;
// while (j <= pointer)
// {
// 	System.out.print(arr[j].size + " ");
//     if(arr[j].size == 7) {System.out.print(" id is "+ arr[j].id +" ");}

// 	j++;
// }

// System.out.print("\n");

// System.out.print("HNode with maximum priority : " +
// 					removeMin().size + "\n");

// // Priority queue after extracting max
// System.out.print("Priority queue after removing minimum : ");
//  j = 0;
// while (j <= pointer)
// {
// 	System.out.print(arr[j].size + " ");
//     if(arr[j].size == 7) {System.out.print(" id is "+ arr[j].id +" ");}

// 	j++;
// }

// System.out.print("\n");

// System.out.print("HNode with maximum priority : " +
// 					removeMin().size + "\n");

// // Priority queue after extracting max
// System.out.print("Priority queue after removing minimum : ");
//  j = 0;
// while (j <= pointer)
// {
// 	System.out.print(arr[j].size + " ");
//     if(arr[j].size == 7) {System.out.print(" id is "+ arr[j].id +" ");}

// 	j++;
// }

// System.out.print("\n");
// */
// // Change the priority of element
// // present at index 2 to 49
// // changePriority(2, 49);
// // System.out.print("Priority queue after " +
// // 				"priority change : ");
// // int k = 0;
// // while (k <= size)
// // {
// // 	System.out.print(H[k] + " ");
// // 	k++;
// // }

// // System.out.print("\n");

// // Remove element at index 3
// // remove(3);
// // System.out.print("Priority queue after " +
// // 				"removing the element : ");
// // int l = 0;
// // while (l <= size)
// // {
// // 	System.out.print(H[l] + " ");
// // 	l++;
// // }
// // }
// }


// }

// class qheap extends myheap {

//     public qheap(int k) {
//         super(k);
//         //TODO Auto-generated constructor stub
//     }

//     @Override
//     void upheap(int j) {
//         while(j> 0 && (arr[parent(j)].key > arr[j].key || ( arr[parent(j)].key == arr[j].key && arr[parent(j)].data > arr[j].data ))){
        
//             swap(j, parent(j));

//             j = parent(j);

//         }
//     }
//     @Override
//     void downheap(int j) {
//         while(hasLeft(j)){
//             //System.out.println("loop started. size is " + pointer);
//             int leftIndex = left(j);
//             int smallChildIndex = leftIndex;
//             if(hasRight(j)){
//                 int rightIndex = right(j);
//                 if (arr[rightIndex].key < arr[leftIndex].key 
//                 || ((arr[rightIndex].key == arr[leftIndex].key && arr[rightIndex].data < arr[leftIndex].data)))
//                 {
//                     smallChildIndex = rightIndex;
//                 }
//             }
//             if(arr[smallChildIndex].key >= arr[j].key){
//                 break;
//             }
//             swap(j,smallChildIndex);
//             j = smallChildIndex;
//         }
//     }
    
// }

// class waiting_heap extends myheap{

//     public waiting_heap(int k) {
//         super(k);
//         //TODO Auto-generated constructor stub
//     }

//     @Override
//     void upheap(int j) {
//         //int parent_var = arr[parent(j)].c.pop_time;
//         //int child_var = arr[j].c.pop_time;
//         while(j> 0 && (arr[parent(j)].c.pop_time > arr[j].key || ( arr[parent(j)].c.pop_time == arr[j].c.pop_time && arr[parent(j)].c.q_id < arr[j].c.q_id ))){
        
//             swap(j, parent(j));

//             j = parent(j);

//         }
//     }
//     @Override
//     void downheap(int j) {
//         while(hasLeft(j)){
//             //System.out.println("loop started. size is " + pointer);
//             int leftIndex = left(j);
//             int smallChildIndex = leftIndex;
//             if(hasRight(j)){
//                 int rightIndex = right(j);
//                 if (arr[rightIndex].key < arr[leftIndex].key 
//                 || ((arr[rightIndex].key == arr[leftIndex].key && arr[rightIndex].data > arr[leftIndex].data)))
//                 {
//                     smallChildIndex = rightIndex;
//                 }
//             }
//             if(arr[smallChildIndex].key >= arr[j].key){
//                 break;
//             }
//             swap(j,smallChildIndex);
//             j = smallChildIndex;
//         }
//     }

// }

// class after_order_heap extends myheap{

//     public after_order_heap(int k) {
//         super(k);
//         //TODO Auto-generated constructor stub
//     }

//     @Override
//     void upheap(int j) {
//         //int parent_var = arr[parent(j)].c.pop_time;
//         //int child_var = arr[j].c.pop_time;
//         while(j> 0 && (arr[parent(j)].c.pop_time > arr[j].key || ( arr[parent(j)].c.pop_time == arr[j].c.pop_time && arr[parent(j)].c.q_id < arr[j].c.q_id ))){
        
//             swap(j, parent(j));

//             j = parent(j);

//         }
//     }
//     @Override
//     void downheap(int j) {
//         while(hasLeft(j)){
//             //System.out.println("loop started. size is " + pointer);
//             int leftIndex = left(j);
//             int smallChildIndex = leftIndex;
//             if(hasRight(j)){
//                 int rightIndex = right(j);
//                 if (arr[rightIndex].key < arr[leftIndex].key 
//                 || ((arr[rightIndex].key == arr[leftIndex].key && arr[rightIndex].data > arr[leftIndex].data)))
//                 {
//                     smallChildIndex = rightIndex;
//                 }
//             }
//             if(arr[smallChildIndex].key >= arr[j].key){
//                 break;
//             }
//             swap(j,smallChildIndex);
//             j = smallChildIndex;
//         }
//     }


    
// }

