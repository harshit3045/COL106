class Burger{
    int cust_id;
    int start_time;
    int end_time;
}

public class MMBurgers implements MMBurgersInterface {

    qheap qh; //this will give us which queue the arriving customer will join
    queue firstq = new queue(); // all customers in this queue until their order is taken
    waiting_heap wait_h = new waiting_heap(100); // heap to arrange customers as per the preference of chef
    queue after_order_queue = new queue(); //after getting arranged this queue stores customers until thier burgers are placed on griddle
    myVector griddle = new myVector(); // griddle to cook bugers

    queue waiting_for_burg = new queue(); // customers after their burgers have reached gridddle
    queue last_queue =new queue(); // stores whose burgers have arrived just before leaving
    avltree tree = new avltree(); // tree to store all customers

    int ptr =0;
    int K=0; //number of counters
    int M = 0; // griddle size
    int globalClockTime=0; 
    int wait_times = 0; // sum of total wait times of all customers
    int number_of_custs = 0; // sum of all customers

    //check if the shop is empty
    public boolean isEmpty(){
        //your implementation
        // if these queues are empty then there's no customers in shop
        if(firstq .size != 0 || waiting_for_burg.size != 0 || last_queue.size != 0)
        return false;
        else return true;
	    //throw new java.lang.UnsupportedOperationException("Not implemented yet.");	
        
    } 
    //setting number of counters
    public void setK(int k) throws IllegalNumberException{
        //your implementation
        //check if it is already initialised
        if(qh != null) {throw new IllegalNumberException("Counters Already initialized");}
        qh = new qheap(k); //create a heap to store all queues
        for( int i = 0; i< k; i++){
            HNode hn = new HNode(0); // a node that refers to the queue size. argument is size ie prop which will be used to sort in heap
            hn.data = i+1; //setting counter id
            hn.time = 0; // counters waiting time
            qh.arr[i] = hn; // adding the node to the heap
            qh.pointer++; // increasing the pointer in heap
        }
        //System.out.println("printing qh arr "+ qh.toString());

        K = k;
        //System.out.println("set k completed");
	    //throw new java.lang.UnsupportedOperationException("Not implemented yet.");	
    }   
    //setting griddle size
    public void setM(int m) throws IllegalNumberException{
        //your implementation
        //check if M is already initialised
        if(m <1 || M != 0)
        throw new IllegalNumberException("Griddle Already initialized");
        
        M = m;

	    //throw new java.lang.UnsupportedOperationException("Not implemented yet.");	
    }

    public void advanceTime(int t) throws IllegalNumberException{
        //your implementation
        
        //check if time already more than this
        if(t < globalClockTime) {throw new IllegalNumberException("Time already more than this");}
        
        // if(t == globalClockTime) {
        //     //System.out.println("advance time called and returned");
        // }


        //Phase I - first q pop until wait time is less than globalclocktime
        // and insert into wait_h and downheap. Here orders are prioritised for chef. Pop this heap until it is empty
        // and store customers into after order queue. Pop this queue and send burger orders into the griddle.
        // customers whose orders are taken are now transferred to waiting for burgs queue
        while(firstq.size != 0 && ((customer)firstq.head.obj).waitTime <= t){
            //getting customer from queues
            customer c = ((customer)firstq.dequeue());
            c.state= K+1;
            c.q_ref.key --;
            qh.downheap(0);
            //System.out.println("testing state"+tree.search(tree.root, c.custId).cust.state);
            
            //sending the customer to wait_heap
            HNode hn = new HNode(c.waitTime);
            hn.data = c.q_id;
            hn.c = c;
            //System.out.println("wait h size is "+wait_h.size());
            //System.out.println("grid size is " + griddle.size);
            wait_h.insert(hn);
            wait_h.downheap(0);
            //if(globalClockTime ==1 )
            //System.out.println("key is "+ wait_h.arr[0].key);
        }

        //emptying the heap to after_order_queue
        while(wait_h.size() != 0){
            HNode n = wait_h.removeMin();
            customer temp_cust = n.c; 
            //System.out.println("nu of burgs is "+ temp_cust.numb);
            after_order_queue.enqueue(temp_cust);
        }
        //placing orders on the griddle
        while(after_order_queue.size != 0){
            for(int i=1;i<= ((customer)after_order_queue.head.obj).numb; i++){
                customer temp_cust = ((customer)after_order_queue.head.obj);
                Burger b= new Burger();
                b.cust_id = temp_cust.custId;
                b.end_time  = temp_cust.waitTime + 10;
                ptr++;
                if( ptr > M && ((Burger)griddle.get(ptr - M)).end_time + 10 > b.end_time){
                    b.end_time = ((Burger)griddle.get(ptr - M)).end_time + 10;
                }
                griddle.enqueue(b);
                //System.out.println("flag");
                //System.out.println(griddle.toString());
            }
            waiting_for_burg.enqueue(after_order_queue.dequeue());
        }

        
        //Phase II -  pop the griddle and complete orders for customers in waiting for burgs queue so long as t is less than gct
        // pop waiting for burgs queue if their orders are completed and transfer them to last queue
        while(griddle.size != 0 && ((Burger)griddle.head.obj).end_time <= t){
            Burger b= (Burger)griddle.dequeue();
            ptr--;
            ((customer)waiting_for_burg.head.obj).waitTime = b.end_time;
            ((customer)waiting_for_burg.head.obj).done_burg ++;
            customer c = ((customer)waiting_for_burg.head.obj);
            if(c.done_burg == c.numb){
                c.waitTime += 1;
                c.state = K+2;
                last_queue.enqueue(waiting_for_burg.dequeue());
            }

        }



        //Phase  III - pop last queue so long as t is less than gct
        while( last_queue.size != 0 && ((customer)last_queue.head.obj).waitTime <= t)
        {

            customer c = (customer)last_queue.dequeue();
            c.state = K+2;
            number_of_custs++;
            wait_times += c.waitTime;
        }

        globalClockTime = t;
        //throw new java.lang.UnsupportedOperationException("Not implemented yet.");	
    } 

    public void arriveCustomer(int id, int t, int numb) throws IllegalNumberException{
        if(t < globalClockTime) {throw new IllegalNumberException("Arrive Custyomer: time already more than this");}
        
        advanceTime(t);
        //find correct queue
        //System.out.println( "qh string " + qh.toString() );
        int q_id = qh.min().data;
        //System.out.println("Queue at top is "+q_id);
        int q_wait_time = qh.min().time;
        //increase queue size
        qh.min().key ++;
        //int q_size = qh.min().key;
        
        //make new customer
        customer c = new customer(id,t,numb);
        c.q_ref = qh.min();

        c.q_id = q_id;
        c.state = q_id;

        //setting wait time of customer
        if(q_wait_time + q_id > t + q_id){
            c.waitTime = q_wait_time + q_id;
            qh.min().time = c.waitTime;
        }
        else {
            c.waitTime = t + q_id;
            qh.min().time = c.waitTime;
        }
        
        
        //System.out.println("cust ID " + c.custId + " q_id is " + q_id);
        //downheap queue
        qh.downheap(0);
        //System.out.println( "qh string later " + qh.toString() );
        // set props: id, arrTime, numb, waitTime, qid, state
        //add customer to first queue
        firstq.enqueue(c);
        //add customer to avl tree
        Node n = new Node(c);
        tree.root = tree.insert(tree.root, n);
        

	    //throw new java.lang.UnsupportedOperationException("Not implemented yet.");	
    } 

    public int customerState(int id, int t) throws IllegalNumberException{
        //your implementation
        if(t < globalClockTime) 
        throw new IllegalNumberException("Customer state: Time already more than this");
        advanceTime(t);
        
        //find customer in avl tree and return its state
        customer c = tree.search(tree.root, id).cust;
        if(c == null) {return 0;}
        return c.state;
	    //throw new java.lang.UnsupportedOperationException("Not implemented yet.");	
        
    } 

    public int griddleState(int t) throws IllegalNumberException{
        //your implementation
        if(t < globalClockTime) throw new IllegalNumberException("Griddle state: Time already more than this");
        if(t > globalClockTime) advanceTime(t);
        
        //System.out.println("griddle state " +globalClockTime + griddle.size + " " + M);

        
        return (griddle.size > M)? M: griddle.size;
        

	    //throw new java.lang.UnsupportedOperationException("Not implemented yet.");	
    }


    public int griddleWait(int t) throws IllegalNumberException{
        //your implementation
        if(t < globalClockTime) throw new IllegalNumberException("Griddle state: Time already more than this");
        if(t > globalClockTime) advanceTime(t);
        //System.out.println("griddle wait " + ptr + " " + M);
        
        if(ptr > M){
            return ptr - M;
        }
        
        return 0;
	    //throw new java.lang.UnsupportedOperationException("Not implemented yet.");	
        
    } 
    //O(height)
    public int customerWaitTime(int id) throws IllegalNumberException{
        //your implementation
        //search in the avl tree and return its wait time
        Node n = tree.search(tree.root, id);
        if(n != null)
        return n.cust.waitTime;

        else throw new IllegalNumberException("customerWaitTime: id not found");
	    //throw new java.lang.UnsupportedOperationException("Not implemented yet.");	
    } 
    //number of customers and sum of their wait times calculated as each customer exits the last queue. 
    //O(1)
	public float avgWaitTime(){
        //your implementation 
        return (float)wait_times / (float)number_of_custs;
    }     
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

class customer{

    int custId;
    int state=0;
    int numb;
    int arrTime;
    int waitTime=0;
    int pop_time=0;
    int q_id=0;
    int cooking_burg = 0;
    int done_burg=0;
    HNode q_ref;

    public customer(int id, int timeofArrival, int burger){
        custId = id;
        numb = burger;
        arrTime = timeofArrival;
        q_ref = null;
    }


}
//HNode Node for heap
class HNode{
    int key; //size
    int data; // id

    customer c;
    int time;
    //myDeque d;
    public HNode(int x){
        key = x;
        data = 0;
    }
}


class myheap {

     HNode arr[] =  new HNode[50];
     int pointer = -1;

    public myheap(int k){
        arr = new HNode[k];
        
        // for (int i = 0; i < k; i++) {
        //  arr[i] = new HNode(i+1);   
        // }

    }
    //return parent of node
     int parent(int j){
        return (j-1) / 2;
    }
    //return left of node
     int left(int j){
        return 2*j +1;
    }
    //return right of node
     int right(int j){
        return 2*j + 2;
    }
    //return left of node
     boolean hasLeft(int j){
        return left(j) <= pointer;

    }
    //return right of Node
     boolean hasRight(int j){
        return right(j) <= pointer;

    }

    //upheap from the Node
     void upheap(int j){

        while(j> 0 && arr[parent(j)].key > arr[j].key){
        
            swap(j, parent(j));

            j = parent(j);

        }
    }
    //downheap from node j
     void downheap(int j){
        //System.out.println("downheap called");
        while(hasLeft(j)){
            //System.out.println("loop started. size is " + pointer);
            int leftIndex = left(j);
            int smallChildIndex = leftIndex;
            if(hasRight(j)){
                int rightIndex = right(j);
                if (arr[rightIndex].key < arr[leftIndex].key)
                {
                    smallChildIndex = rightIndex;
                }
            }
            if(arr[smallChildIndex].key >= arr[j].key){
                break;
            }
            swap(j,smallChildIndex);
            j = smallChildIndex;
        }
    }
    //swap two i, j
     void swap(int i,int j){
        HNode temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

     int size() { return pointer +1;}

     boolean isEmpty() {
        return pointer == -1;
    }
    //return the min(max priority Node)
    HNode min(){
        //System.out.println("min called " + isEmpty());;
        if(isEmpty()) return null;
        else return arr[0];
    }
    //remove the min node and downheap
    HNode removeMin(){
        if(isEmpty()) return null;

        HNode answer = arr[0];
        arr[0] = arr[pointer];
        pointer --;

        downheap(0);
        return answer;
    }
    //insert a node
    HNode insert(HNode q){
        pointer ++;

        arr[pointer] = q;
        //System.out.println(" insert " + pointer + " parent is " + parent(pointer) + " parent data is " + arr[parent(pointer)].data  );
        upheap(pointer);

        return q;
    }
    //return the heap as a tree
    public String toString(){
        String s="";
        for (int i = 0; i < arr.length; i++) {
            s+=arr[i].key + " " +arr[i].data + ", ";
            
        }
        // for (HNode hNode : arr) {
        //     s+=hNode.key + " " +hNode.data + ", ";
        // }
        return s;
    }
    // void queueCustomer(customer c){
    //     c.state = min().id ;
    //     min().enqueue(c);
    //     downheap(0);
    // }


    public static void main(String[] args)
{

/*		      45
			/	 \
		 31 	 14
		/ \      / \
	  13  20    7 11
	 / \
	12 7
	Create a priority queue shown in
	example in a binary max heap form.
	Queue will be represented in the
	form of array as:
	45 31 14 13 20 7 11 12 7 */

// Insert the element to the
// priority queue
/*queue q1= new queue(1);
q1.size = 45;

queue q2= new queue(2);
q2.size = 20;

queue q3= new queue(3);
q3.size = 7;

queue q4= new queue(4);
q4.size = 12;

queue q5= new queue(5);
q5.size = 31;

queue q6= new queue(6);
q6.size = 7;

queue q7= new queue(7);
q7.size = 11;

queue q8= new queue(8);
q8.size = 7;

queue q9= new queue(9);
q9.size = 7;

insert(q1);
insert(q2);
insert(q3);
insert(q4);
insert(q5);
insert(q6);
insert(q7);
insert(q8);
insert(q9);

int i = 0;

// Priority queue before extracting max
System.out.print("#Priority Queue : ");
while (i <= pointer)
{
	System.out.print(arr[i].size + " ");
	i++;
}

System.out.print("\n");

i = 0;

// Priority queue before extracting max
System.out.print("Priority Queue : ");
while (i <= pointer)
{
	System.out.print(arr[i].size + " ");
    if(arr[i].size == 7 ) System.out.print(" id is "+ arr[i].id +" ");
	i++;
}

System.out.print("\n");

// HNode with maximum priority
System.out.print("HNode with maximum priority : " +
					removeMin().size + "\n");

// Priority queue after extracting max
System.out.print("Priority queue after removing minimum : ");
int j = 0;
while (j <= pointer)
{
	System.out.print(arr[j].size + " ");
    if(arr[j].size == 7) {System.out.print(" id is "+ arr[j].id +" ");}
	j++;
}

System.out.print("\n");
//////////////////////////////////////////////////
//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
System.out.print("HNode with maximum priority : " +
					removeMin().size + "\n");

// Priority queue after extracting max
System.out.print("Priority queue after removing minimum : ");
 j = 0;
while (j <= pointer)
{
	System.out.print(arr[j].size + " ");
    if(arr[j].size == 7) {System.out.print(" id is "+ arr[j].id +" ");}

	j++;
}

System.out.print("\n");

System.out.print("HNode with maximum priority : " +
					removeMin().size + "\n");

// Priority queue after extracting max
System.out.print("Priority queue after removing minimum : ");
 j = 0;
while (j <= pointer)
{
	System.out.print(arr[j].size + " ");
    if(arr[j].size == 7) {System.out.print(" id is "+ arr[j].id +" ");}

	j++;
}

System.out.print("\n");

System.out.print("HNode with maximum priority : " +
					removeMin().size + "\n");

// Priority queue after extracting max
System.out.print("Priority queue after removing minimum : ");
 j = 0;
while (j <= pointer)
{
	System.out.print(arr[j].size + " ");
    if(arr[j].size == 7) {System.out.print(" id is "+ arr[j].id +" ");}

	j++;
}

System.out.print("\n");

System.out.print("HNode with maximum priority : " +
					removeMin().size + "\n");

// Priority queue after extracting max
System.out.print("Priority queue after removing minimum : ");
 j = 0;
while (j <= pointer)
{
	System.out.print(arr[j].size + " ");
    if(arr[j].size == 7) {System.out.print(" id is "+ arr[j].id +" ");}

	j++;
}

System.out.print("\n");
*/
// Change the priority of element
// present at index 2 to 49
// changePriority(2, 49);
// System.out.print("Priority queue after " +
// 				"priority change : ");
// int k = 0;
// while (k <= size)
// {
// 	System.out.print(H[k] + " ");
// 	k++;
// }

// System.out.print("\n");

// Remove element at index 3
// remove(3);
// System.out.print("Priority queue after " +
// 				"removing the element : ");
// int l = 0;
// while (l <= size)
// {
// 	System.out.print(H[l] + " ");
// 	l++;
// }
// }
}


}
//qheap - heap to store all queue entities and return which queue the cust will enter
class qheap extends myheap {

    public qheap(int k) {
        super(k);
        //TODO Auto-generated constructor stub
    }
    //override the upheap and downheap to account for priority of different counter id's
    @Override
    void upheap(int j) {
        while(j> 0 && (arr[parent(j)].key > arr[j].key || ( arr[parent(j)].key == arr[j].key && arr[parent(j)].data > arr[j].data ))){
        
            swap(j, parent(j));

            j = parent(j);

        }
    }
    @Override
    void downheap(int j) {
        while(hasLeft(j)){
            //System.out.println("loop started. size is " + pointer);
            int leftIndex = left(j);
            int smallChildIndex = leftIndex;
            if(hasRight(j)){
                int rightIndex = right(j);
                if (arr[rightIndex].key < arr[leftIndex].key 
                || ((arr[rightIndex].key == arr[leftIndex].key && arr[rightIndex].data < arr[leftIndex].data)))
                {
                    smallChildIndex = rightIndex;
                }
            }
            if(arr[smallChildIndex].key > arr[j].key || (arr[smallChildIndex].key == arr[j].key && arr[smallChildIndex].data > arr[j].data)){
                break;
            }
            swap(j,smallChildIndex);
            j = smallChildIndex;
        }
    }
    
}
//waiting_heap to store different customers before chef takes order
class waiting_heap extends myheap{

    public waiting_heap(int k) {
        super(k);
        //TODO Auto-generated constructor stub
    }
    //overriding the upeap and downheap methods to account for chef's priorities based on counter number apart from usual wait times
    @Override
    void upheap(int j) {
        //int parent_var = arr[parent(j)].c.pop_time;
        //int child_var = arr[j].c.pop_time;
        while(j> 0 && 
        (arr[parent(j)].key > arr[j].key || 
        ( arr[parent(j)].c.waitTime == arr[j].c.waitTime && arr[parent(j)].data < arr[j].data )
        )
        ){
        
            swap(j, parent(j));

            j = parent(j);

        }
    }
    @Override
    void downheap(int j) {
        while(hasLeft(j)){
            //System.out.println("loop started. size is " + pointer);
            int leftIndex = left(j);
            int smallChildIndex = leftIndex;
            if(hasRight(j)){
                int rightIndex = right(j);
                if (arr[rightIndex].key < arr[leftIndex].key 
                || ((arr[rightIndex].key == arr[leftIndex].key && arr[rightIndex].data > arr[leftIndex].data)))
                {
                    smallChildIndex = rightIndex;
                }
            }
            if(arr[smallChildIndex].key > arr[j].key || (arr[smallChildIndex].key == arr[j].key && arr[smallChildIndex].data < arr[j].data)){
                break;
            }
            swap(j,smallChildIndex);
            j = smallChildIndex;
        }
    }

}

