class myVector extends queue {

    Object get(int i){
        QNode n = this.head;
        for(int j=1; j<i; j++){
            n = n.next;
        }
        return n.obj;

    }

    public String toString() {
        QNode n = this.head;
        String s= "";
        while( n!= null){
            s += ((Burger) n.obj).end_time + " "+((Burger) n.obj).cust_id + ", " ;
            n = n.next; 
        }
        return s;
    }
}
    // Object arr[] = new Object[20];
    // int ptr = -1;

    // void expand(){

    //     Object temp[] = new Object[arr.length * 2];
    //     int temp_ptr = -1;
    //     for (Object obj : arr) {
    //         temp_ptr ++;
    //         temp[temp_ptr] = obj;
            
    //     }
    //     arr = temp;
    //     ptr = temp_ptr;

    // }

    // void add(Object o){
    //     if(ptr == arr.length -1){
    //         expand();
    //     }
    //     arr[++ptr] = o; 
    // }

    // void addAt(Object o, int i){
    //     arr[i] = o;
    // }

    

    



//     public static void main(String[] args) {
//         myDeque d= new myDeque();
//         myDeque.QNode arr[] = new myDeque.QNode[10];
//         for(int i = 0; i< 10; i++){
//             arr[i] = d.new QNode(i);
//         }

//         d.addFirst(arr[0]);
//         d.addFirst(arr[1]);
//         d.addLast(arr[5]);
//         d.addLast(arr[7]);
//         Object x= 7;

//         int s= (int) x; 
//         System.out.println(d.toString());
//     }

    
// }

// class myDeque{
//     int size= 0;
//     int id;
//     QNode head;
//     QNode tail;

//     myDeque(int d){
//         size = 0;
//         head = null;
//         tail = null;
//         id= d;
//     }

//     class QNode{
//         Object obj;

//         QNode next;
//         QNode prev;
//         public QNode(Object obj){
//             this.obj = obj;
//             this.next = null;
//             this.prev= null;
//         }
//         HNode toHNode(QNode n){
//             customer c= (customer) n.obj;
//             HNode hnode = new HNode(c.waitTime);
//             return hnode;
//         }
//     }

//     public int size() {
//             return size;

//     }

//     public void addFirst(QNode n){
//         if( head == null && tail == null) 
//         {this.head = n; this.tail = n; size ++; return;}
//         this.head.prev = n;
//         n.next  = this.head;
//         this.head = n;
//         size ++;

//     }
//         public void addLast(QNode n){
//             if(tail == null) 
//             {this.head = n; this.tail = n; size ++; return;}
//             tail.next = n;
//             n.prev = tail;
//             this.tail = n;

//             size++;
//         }
//         QNode getFirst(){

//             return head;
//         }
//         QNode getLast(){
//             return tail;
//         }

//         QNode removeFirst(){
//             QNode n = this.head;

//             this.head.next.prev = null;
//             this.head = this.head.next;
//             return n;
//         }
//         QNode removeLast(){

//             QNode n = this.tail;

//             this.tail.prev.next = null;
//             this.tail = this.tail.prev;

//             return n;
//         }

//         public String toString(){
//             String s="";
//             QNode n =this.head;
//             while(n != null){
//                 s += n.obj + " ";
//                 n = n.next;
//             }
//             return s;
//         }


    
// }
