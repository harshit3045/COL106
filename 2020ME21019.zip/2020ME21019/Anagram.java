import java.io.*;
import java.util.*;


class AnagramMap{
    
    @SuppressWarnings("unchecked")
    ArrayList<String>[] anagram_map = new ArrayList[24971];

    int hash(String s){
        long hash = 5381;
        for(Character ch : s.toCharArray()){
            int c = (int) ch;
            hash = ((hash << 5) + hash) + c; /* hash * 33 + c*/ 
        }
        //return hash;
        return (int) Math.floorMod(hash,24971);
    }

    int contains(String s) {

       int hash = hash(s);

        if(anagram_map[hash] == null) return 0;

        for(int i=0;i<anagram_map[hash].size();i++){

            if (anagram_map[hash].get(i).equals(s)) return 1;
			
        }
       
        return 0;
    }

    int put (String s){
        
        int hash = hash(s);
        if(anagram_map[hash] == null)
        anagram_map[hash] = new ArrayList<>();

        anagram_map[hash].add(s);
		return hash;
    }

   
}

class Vocabmap{
    @SuppressWarnings("unchecked")
    ArrayList<ArrayList<String>>[] vocab_map = new ArrayList[40009];
	int size = 24971 ;

    int hash(String s){

        String temp = s;
        //temp= str+"0";
        //int len = str.length();
        int hash = 0;
        char[] chars = temp.toCharArray();
        Arrays.sort(chars);
        for (int i = 0; i < chars.length; i++) {
            hash = (hash * 31 + (int) chars[i]) % 40009;
        }
        return hash%size;
    }

    boolean checkAnagram(String s1,String s2){

            int arr1[]= new int[124];
            int arr2[] = new int[124]; 
            for(int j=0 ; j < s1.length(); j++){
                arr1[s1.charAt(j)] ++;
                arr2[s2.charAt(j)] ++;
            }
            int flag = 1;
            for (int j = 0; j < arr1.length; j++) {
                
                if(arr1[j] != arr2[j]) {flag = 0; break;}
            }


            return (flag == 1);

    }


    ArrayList<String> anagramsOf( String s){
        //int hash = hash(s);
        int hash = hash(s);

        if( vocab_map[hash] == null || vocab_map[hash].size() == 0 )
        return null;

        for (int i = 0; i < vocab_map[hash].size(); i++) {
            if(vocab_map[hash].get(i).get(0).length() != s.length()){
                continue;
            }
            String temp = vocab_map[hash].get(i).get(0);
  
            if(checkAnagram(temp, s)){
                return vocab_map[hash].get(i);
            }
        }
        return null;
    }

	void put(String s)
	{
		int hash = hash(s);
		
        if(vocab_map[hash] == null ){
            vocab_map[hash] = new ArrayList<>();
            ArrayList<String> arrlis = new ArrayList<>();
            arrlis.add(s);
            vocab_map[hash].add(arrlis);
            return;
        }
        if(vocab_map[hash].size() == 0){
            ArrayList<String> arrlis = new ArrayList<>();
            arrlis.add(s);
            vocab_map[hash].add(arrlis);
            return;
        }

		int mapped = 0;

		for(int i = 0;i<vocab_map[hash].size();i++ )
		{
			if (vocab_map[hash].get(i).get(0).length()!= s.length())
				continue;
			String temp = vocab_map[hash].get(i).get(0);
			int x =1;
			if (checkAnagram(temp, s))
			{
				mapped = 1;
				vocab_map[hash].get(i).add(s);
			}
		}
		if (mapped == 0)
		{
			ArrayList<String>ans = new ArrayList<String>();
			ans.add(s);
			vocab_map[hash].add(ans);
		}
	}
}


class Anagram {
    static Vocabmap vocabulary;

   static void makeAnagrams(String input, String p1,String p2,String p3, ArrayList<String> anagram, int ptr, AnagramMap am )
   {
        
        if(ptr == input.length()){


            if((p1.length() < 3) || 
            (p2.length() < 3 && p1.length()!= input.length()) ||
            (p3.length() < 3 && p1.length() + p2.length() != input.length()) ){
                return;
            }

            //if(p1.length() <= 2 || p2.length() <= 2 || p3.length() <= 2) return;

            String joined_String = mergeStrings(p1,p2,p3);

            //System.out.println("Joinde stirng is "+joined_String);

            //System.out.println( anagram_map.hash(joined_String));

            if(am.contains(joined_String) != 0) return;

            ArrayList<String> al1 = new ArrayList<>();
            al1.add("");
            if(p1.length() >=3 )
            al1 = vocabulary.anagramsOf(p1);

            ArrayList<String> al2 = new ArrayList<>();
            al2.add("");
            if(p2.length() >= 3) 
            al2 = vocabulary.anagramsOf(p2);
            

            ArrayList<String> al3 = new ArrayList<>();
            al3.add("");
            if(p3.length() >= 3) 
            al3 = vocabulary.anagramsOf(p3);
            

            if(al1 == null || al2 == null || al3 == null) return;

            for (String string : al1) {
            for (String string2 : al2) {
            for (String string3 : al3) {

                String temp = mergeStrings(string, string2, string3);
                if(temp.length() > 0){
					am.put(temp);
                    anagram.add(temp);
                    
                }

            }    
            }   
            }
            return ;


        }

        makeAnagrams(input, p1 + input.charAt(ptr), p2, p3, anagram, ptr+1, am);
        makeAnagrams(input, p1, p2 + input.charAt(ptr), p3, anagram, ptr+1, am);
        makeAnagrams(input, p1, p2, p3 + input.charAt(ptr), anagram, ptr+1, am);

    
    }
	static String mergeStrings(String p1,String p2, String p3){
        String x = p1 + " " +p2 + " " + p3;
        x= x.trim();
        return x;
    }

    // void anagramPrinter(String s, Vocabmap ht){
       

    // }
    public static void main(String[] args) {
        vocabulary = new Vocabmap();

		File file;
		BufferedReader br;


        long l1 = System.currentTimeMillis();


        try{
			file = new File("vocabulary.txt");
			br= new BufferedReader(new FileReader(file));
			//System.out.println("Line is "+br.readLine());

            int lim = Integer.parseInt(br.readLine());

			String st = br.readLine();

            while((st = br.readLine()) != null){
				vocabulary.put(st);
			}
           
            br.close();

            file = new File("input.txt");
			br = new BufferedReader(new FileReader(file));

            int nextlim = Integer.parseInt(br.readLine());

            for (int i = 0; i < nextlim; i++) {
                String input = br.readLine();
                


                String p1="",p2="",p3="";
                AnagramMap am =  new AnagramMap();
                ArrayList<String> anagram = new ArrayList<>();
                makeAnagrams(input, p1, p2, p3, anagram, 0, am);
                Collections.sort(anagram);
                //int count = 0;
                for (String s : anagram) {
                    //count++;
                    System.out.println(s);
                }

                System.out.println(-1);
                //System.out.println(" Count is " + count);
                
            }
            br.close();

            long l2 = System.currentTimeMillis();
            //System.out.println("Time Taken " + (l2 - l1));

        }catch(Exception e){
            //System.out.println("Wrong input " + e.getMessage());
            //e.printStackTrace();
        }
        
    }
    
}

